let cart = JSON.parse(localStorage.getItem('cart')) || [];

function displayCheckoutDetails() {
  const totalPriceElement = document.getElementById('total-price');
  const grandTotalElement = document.getElementById('grand-total');
  let totalPrice = 0;

  // Calculate total price
  cart.forEach(item => {
    totalPrice += item.price;
  });

  // Update total price and grand total
  totalPriceElement.textContent = totalPrice;
  grandTotalElement.textContent = totalPrice + 200; // Adding Rs. 200 for delivery
}

window.onload = displayCheckoutDetails;