let cart = JSON.parse(localStorage.getItem('cart')) || [];

// Function to render the cart items
function renderCart() {
  const cartItemsContainer = document.getElementById('cart-items');
  const subtotalElement = document.getElementById('subtotal');
  const totalElement = document.getElementById('total');

  cartItemsContainer.innerHTML = ''; // Clear existing items
  let subtotal = 0;

  cart.forEach((item, index) => {
    const row = document.createElement('tr');

    row.innerHTML = `
      <td>${item.name}</td>
      <td>Rs. ${item.price}</td>
    
      <td>Rs. ${item.price}</td>
      <td><button onclick="removeItem(${index})">Remove</button></td>
    `;

    cartItemsContainer.appendChild(row);
    subtotal += item.price;
  });

  subtotalElement.textContent = subtotal;
  totalElement.textContent = subtotal + 200; // Add delivery charges
}

// Function to update item quantity
function updateQuantity(index, newQuantity) {
  cart[index].quantity = parseInt(newQuantity);
  saveCart();
  renderCart();
}

// Function to remove an item
function removeItem(index) {
  cart.splice(index, 1);
  saveCart();
  renderCart();
}

// Function to save the cart to local storage
function saveCart() {
  localStorage.setItem('cart', JSON.stringify(cart));
}

// Initialize the cart on page load
document.addEventListener('DOMContentLoaded', renderCart);