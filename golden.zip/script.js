// Check if user has a preferred theme saved
const modeToggle = document.getElementById('mode-toggle');
const body = document.body;

// Set initial mode based on localStorage or default to light mode
if (localStorage.getItem('theme') === 'dark') {
    body.classList.add('dark-mode');
    modeToggle.checked = true;
} else {
    body.classList.remove('dark-mode');
    modeToggle.checked = false;
}

// Toggle between dark and light modes
modeToggle.addEventListener('change', () => {
    if (modeToggle.checked) {
        body.classList.add('dark-mode');
        localStorage.setItem('theme', 'dark');
    } else {
        body.classList.remove('dark-mode');
        localStorage.setItem('theme', 'light');
    }
});


document.getElementById('searchInput').addEventListener('input', function() {
  const query = this.value.toLowerCase();

  // Search through products (assuming they are in a list with class 'product')
  const products = document.querySelectorAll('.product');

  products.forEach(product => {
    const productName = product.textContent.toLowerCase();
    if (productName.includes(query)) {
      product.style.display = 'block'; // Show matching products
    } else {
      product.style.display = 'none'; // Hide non-matching products
    }
  });
});

// Function to update cart count
function updateCartCount() {
  const cart = JSON.parse(localStorage.getItem('cart')) || [];
  const cartCount = document.getElementById('cart-count');
  cartCount.textContent = cart.length; // Update cart count based on items
}

// Example of adding an item to the cart
function addToCart(product) {
  const cart = JSON.parse(localStorage.getItem('cart')) || [];
  cart.push(product);
  localStorage.setItem('cart', JSON.stringify(cart));

  updateCartCount(); // Update cart count after adding an item
}

// Initial cart count update on page load
updateCartCount();



const slides = document.querySelector('.slider');
const slide = document.querySelectorAll('.slide');
const nextBtn = document.getElementById('nextBtn');
const prevBtn = document.getElementById('prevBtn');

// Unique Slider JavaScript
const uniqueSliderTrack = document.querySelector('.unique-slider-track');
const uniqueSlides = document.querySelectorAll('.unique-slide');
const uniqueNextBtn = document.getElementById('unique-next-btn');
const uniquePrevBtn = document.getElementById('unique-prev-btn');

let uniqueCurrentIndex = 0;

function updateUniqueSliderPosition() {
  const uniqueSlideWidth = uniqueSlides[0].clientWidth;
  uniqueSliderTrack.style.transform = `translateX(${-uniqueSlideWidth * uniqueCurrentIndex}px)`;
}

uniqueNextBtn.addEventListener('click', () => {
  uniqueCurrentIndex = (uniqueCurrentIndex + 1) % uniqueSlides.length;
  updateUniqueSliderPosition();
});

uniquePrevBtn.addEventListener('click', () => {
  uniqueCurrentIndex = (uniqueCurrentIndex - 1 + uniqueSlides.length) % uniqueSlides.length;
  updateUniqueSliderPosition();
});




let cart = JSON.parse(localStorage.getItem('cart')) || [];

function addToCart(productName, productPrice) {
  const product = { name: productName, price: productPrice };
  cart.push(product);
  localStorage.setItem('cart', JSON.stringify(cart)); // Save to localStorage
  updateCartIcon();
}

function updateCartIcon() {
  const cartIcon = document.querySelector('.cart-icon');
  cartIcon.textContent = cart.length;
}



let currentSlide = 0;

function moveSlide(direction) {
  const slides = document.querySelector('.slides');
  const totalSlides = document.querySelectorAll('.slide').length;

  currentSlide += direction;

  if (currentSlide < 0) {
    currentSlide = totalSlides - 1; // Loop to last slide
  } else if (currentSlide >= totalSlides) {
    currentSlide = 0; // Loop to first slide
  }

  const offset = -currentSlide * 300; // Adjust based on slide width
  slides.style.transform = `translateX(${offset}px)`;
}