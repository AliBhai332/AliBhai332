// Global variable to hold attendance data
let attendanceData = {
    totalLectures: 0,
    students: {}
};

// Function to handle form submission and record attendance
document.getElementById('attendanceForm').addEventListener('submit', function (e) {
    e.preventDefault();

    const date = document.getElementById('date').value;
    const time = document.getElementById('time').value;
    const lectureName = document.getElementById('lectureName').value;
    const teacher = document.getElementById('teacher').value;

    const rollNos = [];
    const studentCheckboxes = document.querySelectorAll('.student:checked');
    studentCheckboxes.forEach(checkbox => rollNos.push(checkbox.value));

    attendanceData.totalLectures += 1;

    rollNos.forEach(rollNo => {
        if (!attendanceData.students[rollNo]) {
            attendanceData.students[rollNo] = { totalAttended: 0 };
        }
        attendanceData.students[rollNo].totalAttended += 1;
    });

    const table = document.getElementById('attendanceSummary').getElementsByTagName('tbody')[0];
    const newRow = table.insertRow();
    newRow.insertCell(0).textContent = date;
    newRow.insertCell(1).textContent = time;
    newRow.insertCell(2).textContent = lectureName;
    newRow.insertCell(3).textContent = teacher;
    newRow.insertCell(4).textContent = rollNos.join(', ');
    newRow.insertCell(5).textContent = 'Present';

    document.getElementById('attendanceForm').reset();
});

// Download attendance data as JSON
document.getElementById('downloadBtn').addEventListener('click', function () {
    const jsonData = JSON.stringify(attendanceData, null, 2);
    const hiddenElement = document.createElement('a');
    hiddenElement.href = 'data:text/json;charset=utf-8,' + encodeURIComponent(jsonData);
    hiddenElement.target = '_blank';
    hiddenElement.download = 'attendanceData.json';
    hiddenElement.click();
});

// Consolidate data from multiple files
let consolidatedData = { totalLectures: 0, students: {} };

async function calculateConsolidatedAttendance() {
    const files = document.getElementById('uploadFiles').files;

    if (files.length === 0) {
        alert("Please select one or more attendance files.");
        return;
    }

    consolidatedData = { totalLectures: 0, students: {} };

    for (const file of files) {
        const fileData = await readFileAsync(file);
        mergeAttendanceData(fileData);
    }

    displayConsolidatedAttendancePercentage();
}

// Utility function to read a file as JSON
function readFileAsync(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = event => resolve(JSON.parse(event.target.result));
        reader.onerror = error => reject(error);
        reader.readAsText(file);
    });
}

// Merge attendance data from each file into consolidatedData
function mergeAttendanceData(fileData) {
    if (!fileData || !fileData.students) return;

    consolidatedData.totalLectures += fileData.totalLectures;

    for (const rollNo in fileData.students) {
        if (!consolidatedData.students[rollNo]) {
            consolidatedData.students[rollNo] = { totalAttended: 0 };
        }
        consolidatedData.students[rollNo].totalAttended += fileData.students[rollNo].totalAttended;
    }
}

// Display consolidated attendance percentages
function displayConsolidatedAttendancePercentage() {
    const attendancePercentageDiv = document.getElementById('attendancePercentage');
    attendancePercentageDiv.innerHTML = "<h3>Consolidated Attendance Percentages</h3>";

    for (const rollNo in consolidatedData.students) {
        const student = consolidatedData.students[rollNo];
        const percentage = (student.totalAttended / consolidatedData.totalLectures) * 100;
        attendancePercentageDiv.innerHTML += `
            <p>Roll No. ${rollNo}: ${percentage.toFixed(2)}% 
            (Attended: ${student.totalAttended}/${consolidatedData.totalLectures})</p>
        `;
    }
}